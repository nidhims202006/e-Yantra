// datapath.v
module datapath (
    input         clk, reset,
    input [1:0]   ResultSrc,
    input         PCSrc, ALUSrc,
    input         RegWrite,
    input [1:0]   ImmSrc,
    input [2:0]   ALUControl,
    output        Zero,
    output [31:0] PC,
    input  [31:0] Instr,
    output [31:0] Mem_WrAddr, Mem_WrData,
    input  [31:0] ReadData,
    output [31:0] Result
);

wire [31:0] PCNext, PCPlus4, PCTarget, PCTargetFinal;
wire [31:0] ImmExt, UImmExt, SrcA, SrcB, WriteData, ALUResult;
wire [31:0] RegSrcA;
wire [31:0] JALRTarget;

wire is_lui;
wire is_auipc;
wire is_jalr;

assign is_lui   = (Instr[6:0] == 7'b0110111);
assign is_auipc = (Instr[6:0] == 7'b0010111);
assign is_jalr  = (Instr[6:0] == 7'b1100111);

// U-type immediate
assign UImmExt = {Instr[31:12], 12'b0};

// next PC logic
reset_ff #(32) pcreg(clk, reset, PCNext, PC);
adder          pcadd4(PC, 32'd4, PCPlus4);
adder          pcaddbranch(PC, ImmExt, PCTarget);

// JALR target = rs1 + immediate
adder          jalradd(RegSrcA, ImmExt, JALRTarget);

// Select branch/JAL target or JALR target
mux2 #(32)     targetmux(PCTarget, JALRTarget, is_jalr, PCTargetFinal);
mux2 #(32)     pcmux(PCPlus4, PCTargetFinal, PCSrc, PCNext);

// register file logic
reg_file rf (
    clk,
    RegWrite,
    Instr[19:15],
    Instr[24:20],
    Instr[11:7],
    Result,
    RegSrcA,
    WriteData
);

imm_extend ext (Instr[31:7], ImmSrc, ImmExt);

// AUIPC uses PC as ALU input
mux2 #(32) srcamux(RegSrcA, PC, is_auipc, SrcA);

// LUI/AUIPC use U-type immediate
mux2 #(32) srcbmux(
    WriteData,
    (is_lui || is_auipc) ? UImmExt : ImmExt,
    ALUSrc,
    SrcB
);

// ALU logic
alu alu (SrcA, SrcB, ALUControl, ALUResult, Zero);

mux3 #(32) resultmux(
    ALUResult,
    ReadData,
    PCPlus4,
    ResultSrc,
    Result
);

assign Mem_WrData = WriteData;
assign Mem_WrAddr = ALUResult;

endmodule