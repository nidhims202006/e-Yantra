// data_mem.v - data memory

module data_mem #(parameter DATA_WIDTH = 32, ADDR_WIDTH = 32, MEM_SIZE = 64) (
    input       clk, wr_en,
    input       [ADDR_WIDTH-1:0] wr_addr, wr_data,
    input       [2:0] funct3,
    output reg  [DATA_WIDTH-1:0] rd_data_mem
);

// array of 64 32-bit words or data
reg [DATA_WIDTH-1:0] data_ram [0:MEM_SIZE-1];

wire [31:0] mem_word;

assign mem_word = data_ram[wr_addr[DATA_WIDTH-1:2] % MEM_SIZE];

// combinational read logic
always @(*) begin
    case (funct3)

        3'b000: begin
            // LB - sign extend byte
            case (wr_addr[1:0])
                2'b00: rd_data_mem = {{24{mem_word[7]}},  mem_word[7:0]};
                2'b01: rd_data_mem = {{24{mem_word[15]}}, mem_word[15:8]};
                2'b10: rd_data_mem = {{24{mem_word[23]}}, mem_word[23:16]};
                2'b11: rd_data_mem = {{24{mem_word[31]}}, mem_word[31:24]};
            endcase
        end

        3'b001: begin
            // LH - sign extend halfword
            if (wr_addr[1] == 1'b0)
                rd_data_mem = {{16{mem_word[15]}}, mem_word[15:0]};
            else
                rd_data_mem = {{16{mem_word[31]}}, mem_word[31:16]};
        end

        3'b010: begin
            // LW
            rd_data_mem = mem_word;
        end

        3'b100: begin
            // LBU - zero extend byte
            case (wr_addr[1:0])
                2'b00: rd_data_mem = {24'b0, mem_word[7:0]};
                2'b01: rd_data_mem = {24'b0, mem_word[15:8]};
                2'b10: rd_data_mem = {24'b0, mem_word[23:16]};
                2'b11: rd_data_mem = {24'b0, mem_word[31:24]};
            endcase
        end

        3'b101: begin
            // LHU - zero extend halfword
            if (wr_addr[1] == 1'b0)
                rd_data_mem = {16'b0, mem_word[15:0]};
            else
                rd_data_mem = {16'b0, mem_word[31:16]};
        end

        default: begin
            rd_data_mem = mem_word;
        end

    endcase
end

// synchronous write logic
always @(posedge clk) begin
    if (wr_en)
        data_ram[wr_addr[DATA_WIDTH-1:2] % MEM_SIZE] <= wr_data;
end

endmodule