// controller.v - controller for RISC-V CPU

module controller (
    input [6:0]  op,
    input [2:0]  funct3,
    input        funct7b5,
    input        Zero,
    input        LessSigned,
    input        LessUnsigned,

    output       [1:0] ResultSrc,
    output       MemWrite,
    output       PCSrc,
    output       ALUSrc,
    output       RegWrite,
    output       Jump,
    output [1:0] ImmSrc,
    output [3:0] ALUControl
);

wire [1:0] ALUOp;
wire       Branch;

main_decoder md (
    op,
    ResultSrc,
    MemWrite,
    Branch,
    ALUSrc,
    RegWrite,
    Jump,
    ImmSrc,
    ALUOp
);

alu_decoder ad (
    op[5],
    funct3,
    funct7b5,
    ALUOp,
    ALUControl
);

reg branch_taken;

always @(*) begin
    branch_taken = 1'b0;

    if (Branch) begin
        case (funct3)

            3'b000: branch_taken = Zero;          // BEQ
            3'b001: branch_taken = ~Zero;         // BNE
            3'b100: branch_taken = LessSigned;    // BLT
            3'b101: branch_taken = ~LessSigned;   // BGE
            3'b110: branch_taken = LessUnsigned;  // BLTU
            3'b111: branch_taken = ~LessUnsigned; // BGEU

            default: branch_taken = 1'b0;

        endcase
    end
end

assign PCSrc = branch_taken | Jump;

endmodule