// alu.v - Arithmetic Logic Unit

module alu (
    input  [31:0] SrcA,
    input  [31:0] SrcB,
    input  [3:0]  ALUControl,

    output [31:0] ALUResult,
    output        Zero,
    output        LessSigned,
    output        LessUnsigned
);

reg [31:0] result;

always @(*) begin

    case (ALUControl)

        4'b0000: begin
            result = SrcA + SrcB;                    // ADD
        end

        4'b0001: begin
            result = SrcA - SrcB;                    // SUB
        end

        4'b0010: begin
            result = SrcA & SrcB;                    // AND
        end

        4'b0011: begin
            result = SrcA | SrcB;                    // OR
        end

        4'b0100: begin
            result = SrcA ^ SrcB;                    // XOR
        end

        4'b0101: begin
            result = ($signed(SrcA) < $signed(SrcB))
                     ? 32'd1 : 32'd0;                // SLT
        end

        4'b0110: begin
            result = (SrcA < SrcB)
                     ? 32'd1 : 32'd0;                // SLTU
        end

        4'b0111: begin
            result = SrcA << SrcB[4:0];              // SLL
        end

        4'b1000: begin
            result = SrcA >> SrcB[4:0];              // SRL
        end

        4'b1001: begin
            result = $signed(SrcA) >>> SrcB[4:0];    // SRA
        end

        default: begin
            result = 32'd0;
        end

    endcase

end

assign ALUResult   = result;
assign Zero        = (result == 32'd0);
assign LessSigned  = ($signed(SrcA) < $signed(SrcB));
assign LessUnsigned = (SrcA < SrcB);

endmodule