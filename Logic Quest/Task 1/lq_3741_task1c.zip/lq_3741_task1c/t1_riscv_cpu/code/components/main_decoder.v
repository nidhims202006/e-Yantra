// main_decoder.v - main control decoder for RISC-V CPU

module main_decoder (
    input  [6:0] op,

    output [1:0] ResultSrc,
    output       MemWrite,
    output       Branch,
    output       ALUSrc,
    output       RegWrite,
    output       Jump,
    output [1:0] ImmSrc,
    output [1:0] ALUOp
);

reg [10:0] controls;

always @(*) begin

    case (op)

        // RegWrite_ImmSrc_ALUSrc_MemWrite_ResultSrc_Branch_ALUOp_Jump

        // Loads: LB, LH, LW, LBU, LHU
        7'b0000011:
            controls = 11'b1_00_1_0_01_0_00_0;

        // Stores: SB, SH, SW
        7'b0100011:
            controls = 11'b0_10_1_1_00_0_00_0;

        // R-type ALU instructions
        // ADD, SUB, SLL, SLT, SLTU, XOR, SRL, SRA, OR, AND
        7'b0110011:
            controls = 11'b0_xx_0_0_00_0_10_0;

        // Branches:
        // BEQ, BNE, BLT, BGE, BLTU, BGEU
        7'b1100011:
            controls = 11'b0_10_0_0_00_1_01_0;

        // I-type ALU instructions
        // ADDI, SLLI, SLTI, SLTIU, XORI, SRLI, SRAI, ORI, ANDI
        7'b0010011:
            controls = 11'b1_00_1_0_00_0_10_0;

        // LUI
        7'b0110111:
            controls = 11'b1_xx_1_0_00_0_00_0;

        // AUIPC
        7'b0010111:
            controls = 11'b1_xx_1_0_00_0_00_0;

        // JALR
        7'b1100111:
            controls = 11'b1_00_1_0_10_0_00_1;

        // JAL
        7'b1101111:
            controls = 11'b1_11_0_0_10_0_00_1;

        default:
            controls = 11'b0_00_0_0_00_0_00_0;

    endcase

end

assign {
    RegWrite,
    ImmSrc,
    ALUSrc,
    MemWrite,
    ResultSrc,
    Branch,
    ALUOp,
    Jump
} = controls;

endmodule