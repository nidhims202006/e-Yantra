#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry, Path
from sensor_msgs.msg import LaserScan

from rclpy.qos import (
    qos_profile_sensor_data,
    QoSProfile,
    ReliabilityPolicy,
    DurabilityPolicy
)


path_topic = '/ebot_path'
odom_topic = '/odom'
scan_topic = '/scan'
cmd_topic = '/cmd_vel'

max_linear_mps = 0.5
max_angular_rps = 1.0


class ebot_nav(Node):

    def __init__(self):

        super().__init__('ebot_nav')

        # -------------------------------------------------
        # PATH QoS
        # -------------------------------------------------

        path_qos = QoSProfile(
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL
        )

        # -------------------------------------------------
        # SUBSCRIBERS
        # -------------------------------------------------

        self.path_sub = self.create_subscription(
            Path,
            path_topic,
            self.pathcb,
            path_qos
        )

        self.odom_sub = self.create_subscription(
            Odometry,
            odom_topic,
            self.odomcb,
            10
        )

        self.scan_sub = self.create_subscription(
            LaserScan,
            scan_topic,
            self.scancb,
            qos_profile_sensor_data
        )

        # -------------------------------------------------
        # PUBLISHER
        # -------------------------------------------------

        self.cmd_pub = self.create_publisher(
            Twist,
            cmd_topic,
            10
        )

        # -------------------------------------------------
        # TIMER
        # -------------------------------------------------

        self.timer = self.create_timer(
            0.05,
            self.process_navigation
        )

        # -------------------------------------------------
        # VARIABLES
        # -------------------------------------------------

        self.route = None
        self.odom = None
        self.scan = None

        self.waypoints = []
        self.current_waypoint = 0

        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_yaw = 0.0

        self.route_received = False
        self.finished = False

        # Obstacle avoidance state
        self.avoiding_obstacle = False
        self.avoid_direction = 0.0

        self.get_logger().info(
            'eBot path follower started'
        )


    # =====================================================
    # PATH CALLBACK
    # =====================================================

    def pathcb(self, data):

        self.route = data

        self.waypoints = []

        for pose in data.poses:

            x = pose.pose.position.x
            y = pose.pose.position.y

            self.waypoints.append((x, y))

        self.current_waypoint = 0

        self.finished = False
        self.route_received = True
        self.avoiding_obstacle = False

        self.get_logger().info(
            f'Received route with {len(self.waypoints)} '
            f'waypoints in frame {data.header.frame_id}'
        )

        for i, (x, y) in enumerate(self.waypoints):

            self.get_logger().info(
                f'Waypoint {i + 1}: '
                f'x={x:.3f}, y={y:.3f}'
            )


    # =====================================================
    # ODOM CALLBACK
    # =====================================================

    def odomcb(self, msg):

        self.odom = msg

        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y

        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w

        siny_cosp = 2.0 * (
            qw * qz + qx * qy
        )

        cosy_cosp = 1.0 - 2.0 * (
            qy * qy + qz * qz
        )

        self.robot_yaw = math.atan2(
            siny_cosp,
            cosy_cosp
        )


    # =====================================================
    # LASER CALLBACK
    # =====================================================

    def scancb(self, msg):

        self.scan = msg


    # =====================================================
    # GET DISTANCE IN ANGLE RANGE
    # =====================================================

    def get_sector_distance(
        self,
        min_angle,
        max_angle
    ):

        if self.scan is None:
            return 8.0

        values = []

        for i, distance in enumerate(
            self.scan.ranges
        ):

            angle = (
                self.scan.angle_min
                + i * self.scan.angle_increment
            )

            if min_angle <= angle <= max_angle:

                if math.isfinite(distance):

                    if (
                        distance >= self.scan.range_min
                        and distance <= self.scan.range_max
                    ):

                        values.append(distance)

        if not values:
            return 8.0

        return min(values)


    # =====================================================
    # NAVIGATION
    # =====================================================

    def process_navigation(self):

        cmd = Twist()

        # -------------------------------------------------
        # WAIT FOR ROUTE
        # -------------------------------------------------

        if not self.route_received:

            self.cmd_pub.publish(cmd)

            return

        # -------------------------------------------------
        # WAIT FOR ODOM
        # -------------------------------------------------

        if self.odom is None:

            self.cmd_pub.publish(cmd)

            return

        # -------------------------------------------------
        # NO WAYPOINTS
        # -------------------------------------------------

        if len(self.waypoints) == 0:

            self.cmd_pub.publish(cmd)

            return

        # -------------------------------------------------
        # FINISHED
        # -------------------------------------------------

        if self.finished:

            self.cmd_pub.publish(cmd)

            return

        # -------------------------------------------------
        # CURRENT WAYPOINT
        # -------------------------------------------------

        target_x, target_y = self.waypoints[
            self.current_waypoint
        ]

        dx = target_x - self.robot_x
        dy = target_y - self.robot_y

        distance = math.sqrt(
            dx * dx + dy * dy
        )

        # -------------------------------------------------
        # WAYPOINT REACHED
        # -------------------------------------------------

        if distance <= 0.25:

            self.get_logger().info(
                f'Reached waypoint '
                f'{self.current_waypoint + 1}'
            )

            self.current_waypoint += 1

            if (
                self.current_waypoint
                >= len(self.waypoints)
            ):

                self.finished = True

                self.cmd_pub.publish(
                    Twist()
                )

                self.get_logger().info(
                    'All waypoints reached. '
                    'Robot stopped.'
                )

                return

            self.avoiding_obstacle = False

            self.cmd_pub.publish(
                Twist()
            )

            return

        # -------------------------------------------------
        # TARGET ANGLE
        # -------------------------------------------------

        target_angle = math.atan2(
            dy,
            dx
        )

        angle_error = (
            target_angle
            - self.robot_yaw
        )

        # Normalize angle

        while angle_error > math.pi:

            angle_error -= 2.0 * math.pi

        while angle_error < -math.pi:

            angle_error += 2.0 * math.pi

        # -------------------------------------------------
        # LASER SECTORS
        # -------------------------------------------------

        front = self.get_sector_distance(
            math.radians(-25),
            math.radians(25)
        )

        left = self.get_sector_distance(
            math.radians(30),
            math.radians(90)
        )

        right = self.get_sector_distance(
            math.radians(-90),
            math.radians(-30)
        )

        # -------------------------------------------------
        # OBSTACLE THRESHOLDS
        # -------------------------------------------------

        emergency_distance = 0.35
        obstacle_distance = 0.55
        clear_distance = 0.80

        # -------------------------------------------------
        # START OBSTACLE AVOIDANCE
        # -------------------------------------------------

        if not self.avoiding_obstacle:

            if front < obstacle_distance:

                self.avoiding_obstacle = True

                if left > right:

                    self.avoid_direction = 1.0

                else:

                    self.avoid_direction = -1.0

                self.get_logger().info(
                    'Obstacle detected - avoiding'
                )

        # -------------------------------------------------
        # OBSTACLE AVOIDANCE
        # -------------------------------------------------

        if self.avoiding_obstacle:

            # Emergency: obstacle extremely close

            if front < emergency_distance:

                cmd.linear.x = 0.0

                cmd.angular.z = (
                    0.9
                    * self.avoid_direction
                )

                self.cmd_pub.publish(cmd)

                return

            # Still blocked

            if front < clear_distance:

                cmd.linear.x = 0.08

                cmd.angular.z = (
                    0.65
                    * self.avoid_direction
                )

                self.cmd_pub.publish(cmd)

                return

            # Obstacle cleared

            self.avoiding_obstacle = False

            self.get_logger().info(
                'Obstacle cleared - resuming path'
            )

        # -------------------------------------------------
        # NORMAL PATH FOLLOWING
        # -------------------------------------------------

        # Large heading error:
        # rotate mostly in place

        if abs(angle_error) > math.radians(35):

            cmd.linear.x = 0.05

        else:

            # Slow down when close to waypoint

            if distance < 1.0:

                cmd.linear.x = 0.18

            elif distance < 2.0:

                cmd.linear.x = 0.30

            else:

                cmd.linear.x = 0.40

        # -------------------------------------------------
        # ANGULAR CONTROL
        # -------------------------------------------------

        cmd.angular.z = (
            1.5 * angle_error
        )

        cmd.angular.z = max(
            -max_angular_rps,
            min(
                max_angular_rps,
                cmd.angular.z
            )
        )

        # -------------------------------------------------
        # EXTRA SAFETY
        # -------------------------------------------------

        if front < 0.75:

            cmd.linear.x = min(
                cmd.linear.x,
                0.15
            )

        # -------------------------------------------------
        # PUBLISH
        # -------------------------------------------------

        self.cmd_pub.publish(cmd)


# =========================================================
# MAIN
# =========================================================

def main(args=None):

    rclpy.init(args=args)

    node = ebot_nav()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    finally:

        node.cmd_pub.publish(
            Twist()
        )

        node.destroy_node()

        rclpy.shutdown()


if __name__ == '__main__':

    main()
