#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import TransformStamped
from cv_bridge import CvBridge
import cv2
import numpy as np
import tf2_ros

class OreDetectorNode(Node):
    def __init__(self):
        super().__init__('ore_detector')

        if not self.has_parameter('use_sim_time'):
            self.declare_parameter('use_sim_time', True)

        self.get_logger().info("Task 1A Ore Perception Node Starting...")

        self.bridge = CvBridge()

        # Camera intrinsics storage
        self.camera_info_received = False
        self.fx = None
        self.fy = None
        self.cx = None
        self.cy = None

        # Images storage
        self.cv_color_image = None
        self.cv_depth_image = None

        # Subscriptions
        self.create_subscription(CameraInfo, '/camera/camera/color/camera_info', self.camera_info_cb, 10)
        self.create_subscription(Image, '/camera/camera/color/image_raw', self.color_image_cb, 10)
        self.create_subscription(Image, '/camera/camera/aligned_depth_to_color/image_raw', self.depth_image_cb, 10)

        # TF2 Listener & Broadcaster
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)

        # Timer loop for detection & TF broadcasting (10 Hz)
        self.timer = self.create_timer(0.1, self.process_and_broadcast)

        # Robust HSV Threshold Ranges for OpenCV Segmentation
        self.color_ranges = {
            'azurite': {
                'lower': np.array([95, 100, 60]),
                'upper': np.array([135, 255, 255])
            },
            'malachite': {
                'lower': np.array([35, 80, 50]),
                'upper': np.array([85, 255, 255])
            },
            'vanadinite': {
                'lower': np.array([2, 80, 60]),   # Optimized for low-light & shadowed orange ores
                'upper': np.array([25, 255, 255])
            }
        }

    def camera_info_cb(self, msg: CameraInfo):
        if not self.camera_info_received:
            self.fx = msg.k[0]
            self.fy = msg.k[4]
            self.cx = msg.k[2]
            self.cy = msg.k[5]
            self.camera_info_received = True

    def color_image_cb(self, msg: Image):
        try:
            self.cv_color_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f"Error converting color image: {e}")

    def depth_image_cb(self, msg: Image):
        try:
            if msg.encoding in ['16UC1', 'mono16']:
                depth_cv = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
                self.cv_depth_image = depth_cv.astype(np.float32) / 1000.0  # mm to meters
            else:
                self.cv_depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='32FC1')
        except Exception as e:
            self.get_logger().error(f"Error converting depth image: {e}")

    def quaternion_to_rotation_matrix(self, q):
        x, y, z, w = q.x, q.y, q.z, q.w
        return np.array([
            [1 - 2*(y**2 + z**2), 2*(x*y - z*w),     2*(x*z + y*w)],
            [2*(x*y + z*w),     1 - 2*(x**2 + z**2), 2*(y*z - x*w)],
            [2*(x*z - y*w),     2*(y*z + x*w),     1 - 2*(x**2 + y**2)]
        ])

    def transform_camera_to_base(self, p_cam):
        try:
            tf_stamped = self.tf_buffer.lookup_transform(
                'base_link',
                'camera_color_optical_frame',
                rclpy.time.Time(),
                timeout=rclpy.duration.Duration(seconds=0.5)
            )
            t = tf_stamped.transform.translation
            r = tf_stamped.transform.rotation

            T = np.array([t.x, t.y, t.z])
            R = self.quaternion_to_rotation_matrix(r)

            p_base = np.dot(R, np.array(p_cam)) + T
            return p_base
        except Exception as e:
            self.get_logger().warn(f"TF Lookup failed: {e}")
            return None

    def get_patch_depth(self, u, v, window=7):
        if self.cv_depth_image is None:
            return 0.0

        h, w = self.cv_depth_image.shape
        u_min, u_max = max(0, u - window), min(w - 1, u + window)
        v_min, v_max = max(0, v - window), min(h - 1, v + window)

        patch = self.cv_depth_image[v_min:v_max+1, u_min:u_max+1]
        valid_depths = patch[(patch > 0.1) & (~np.isnan(patch)) & (~np.isinf(patch))]

        if len(valid_depths) > 0:
            return float(np.median(valid_depths))
        return 0.0

    def process_and_broadcast(self):
        if not self.camera_info_received or self.cv_color_image is None or self.cv_depth_image is None:
            return

        display_img = self.cv_color_image.copy()
        hsv_img = cv2.cvtColor(self.cv_color_image, cv2.COLOR_BGR2HSV)

        for ore_type, ranges in self.color_ranges.items():
            mask = cv2.inRange(hsv_img, ranges['lower'], ranges['upper'])

            # Morphological noise filtering
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            valid_ores = []
            for cnt in contours:
                area = cv2.contourArea(cnt)
                if 80 < area < 5000:
                    M = cv2.moments(cnt)
                    if M["m00"] != 0:
                        cx_pixel = int(M["m10"] / M["m00"])
                        cy_pixel = int(M["m01"] / M["m00"])

                        # Conveyor Belt ROI Constraint: filter out hopper (x < 300)
                        if cx_pixel > 300:
                            valid_ores.append((cx_pixel, cy_pixel, cnt))

            # Sort detected contours top-to-bottom along the conveyor belt (Y coordinate)
            valid_ores.sort(key=lambda item: item[1])

            for idx, (u, v, cnt) in enumerate(valid_ores[:2]):
                transform_name = f"{ore_type}_ore_{idx + 1}"

                # 1. Median depth at centroid
                z_c = self.get_patch_depth(u, v)
                if z_c <= 0.0:
                    continue

                # 2. Back-project to 3D in camera_color_optical_frame
                x_c = (u - self.cx) * z_c / self.fx
                y_c = (v - self.cy) * z_c / self.fy
                p_cam = [x_c, y_c, z_c]

                # 3. Transform to base_link
                p_base = self.transform_camera_to_base(p_cam)
                if p_base is None:
                    continue

                # 4. Broadcast tf2 transform
                t = TransformStamped()
                t.header.stamp = self.get_clock().now().to_msg()
                t.header.frame_id = 'base_link'
                t.child_frame_id = transform_name
                t.transform.translation.x = float(p_base[0])
                t.transform.translation.y = float(p_base[1])
                t.transform.translation.z = float(p_base[2])

                # Identity orientation
                t.transform.rotation.x = 0.0
                t.transform.rotation.y = 0.0
                t.transform.rotation.z = 0.0
                t.transform.rotation.w = 1.0

                self.tf_broadcaster.sendTransform(t)

                # 5. Draw bounding box and label for screenshot submission
                x, y, w_box, h_box = cv2.boundingRect(cnt)
                cv2.rectangle(display_img, (x, y), (x + w_box, y + h_box), (0, 255, 0), 2)
                cv2.putText(display_img, transform_name, (x, max(15, y - 5)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2)

        # Show OpenCV detection window
        cv2.imshow("Task 1A - Ore Detection Window", display_img)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    node = OreDetectorNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        cv2.destroyAllWindows()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
