#!/usr/bin/env python3

import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped, PoseStamped
from sensor_msgs.msg import JointState
from control_msgs.msg import JointJog
from std_msgs.msg import Int32
from rclpy.qos import qos_profile_sensor_data
from controller_manager_msgs.srv import SwitchController

class Task1BController(Node):
    def __init__(self):
        super().__init__('arm_waypoints')
        
        if not self.has_parameter('use_sim_time'):
            self.declare_parameter('use_sim_time', True)

        self.twist_pub = self.create_publisher(TwistStamped, '/delta_twist_cmds', 10)
        self.joint_pub = self.create_publisher(JointJog, '/delta_joint_cmds', 10)
        
        self.create_subscription(PoseStamped, '/tcp_pose_raw', self.pose_cb, qos_profile_sensor_data)
        self.create_subscription(JointState, '/joint_states', self.joint_cb, qos_profile_sensor_data)
        self.create_subscription(Int32, '/arm_status', self.status_cb, 10)

        self.switch_cli = self.create_client(SwitchController, '/ur_arm_controller/switch_controller')

        self.waypoints = [
            [-0.4085, -0.5379, 0.1967],
            [-0.8000, -0.0005, 0.3987],
            [-0.7430,  0.5280, 0.1967],
            [-0.4097,  0.5280, 0.1967],
            [-0.0763,  0.5280, 0.1967]
        ]
        
        self.state = 'WAIT_TELEMETRY'
        self.pose = None
        self.joints = {}
        self.arm_status = 0
        self.wp_idx = 0
        self.hold_start = 0.0
        self.switch_future = None

        self.get_logger().info("Task 1B Controller Started")
        self.timer = self.create_timer(0.02, self.control_loop)

    def pose_cb(self, msg):
        self.pose = msg.pose.position

    def joint_cb(self, msg):
        for i, name in enumerate(msg.name):
            self.joints[name] = msg.position[i]

    def status_cb(self, msg):
        self.arm_status = msg.data

    def request_switch(self, activate, deactivate):
        req = SwitchController.Request()
        req.activate_controllers = [activate]
        req.deactivate_controllers = [deactivate]
        req.strictness = 1
        self.switch_future = self.switch_cli.call_async(req)

    def publish_zero_twist(self):
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        self.twist_pub.publish(msg)

    def publish_zero_joint(self):
        msg = JointJog()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.joint_names = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
        msg.velocities = [0.0] * 6
        self.joint_pub.publish(msg)

    def control_loop(self):
        now = self.get_clock().now().nanoseconds / 1e9

        if self.arm_status >= 20:
            if self.state in ['UNFOLD', 'SWITCHING_TO_TWIST']:
                self.publish_zero_joint()
            else:
                self.publish_zero_twist()
            return

        if self.pose is None or not self.joints:
            return

        if self.state == 'WAIT_TELEMETRY':
            if self.switch_cli.service_is_ready():
                self.request_switch('delta_joint_controller', 'delta_twist_controller')
                self.state = 'SWITCHING_TO_JOINT'
            
        elif self.state == 'SWITCHING_TO_JOINT':
            if self.switch_future.done():
                res = self.switch_future.result()
                if res and res.ok:
                    self.state = 'UNFOLD'
                else:
                    self.state = 'WAIT_TELEMETRY'

        elif self.state == 'UNFOLD':
            sl_err = -1.20 - self.joints.get('shoulder_lift_joint', 0.0)
            el_err = -1.60 - self.joints.get('elbow_joint', 0.0)
            w1_err = -1.90 - self.joints.get('wrist_1_joint', 0.0)

            if abs(sl_err) < 0.05 and abs(el_err) < 0.05 and abs(w1_err) < 0.05:
                self.publish_zero_joint()
                self.request_switch('delta_twist_controller', 'delta_joint_controller')
                self.state = 'SWITCHING_TO_TWIST'
                return

            msg = JointJog()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'base_link'
            msg.joint_names = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
            v_sl = max(min(sl_err, 0.20), -0.20)
            v_el = max(min(el_err, 0.20), -0.20)
            v_w1 = max(min(w1_err, 0.20), -0.20)
            msg.velocities = [0.0, float(v_sl), float(v_el), float(v_w1), 0.0, 0.0]
            self.joint_pub.publish(msg)

        elif self.state == 'SWITCHING_TO_TWIST':
            if self.switch_future.done():
                res = self.switch_future.result()
                if res and res.ok:
                    self.state = 'TRACK'
                else:
                    self.state = 'UNFOLD' 

        elif self.state == 'TRACK':
            target = self.waypoints[self.wp_idx]
            dx = target[0] - self.pose.x
            dy = target[1] - self.pose.y
            dz = target[2] - self.pose.z
            dist = math.sqrt(dx**2 + dy**2 + dz**2)

            if dist <= 0.015:
                self.get_logger().info(f"WP {self.wp_idx + 1} reached! Stopping dead.")
                self.hold_start = now
                self.state = 'HOLD'
                self.publish_zero_twist()
                return

            speed = min(1.0 * dist, 0.06)
            
            if self.arm_status == 11:
                speed *= 0.5
            
            msg = TwistStamped()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'base_link'
            msg.twist.linear.x = (dx / dist) * speed
            msg.twist.linear.y = (dy / dist) * speed
            msg.twist.linear.z = (dz / dist) * speed
            self.twist_pub.publish(msg)

        elif self.state == 'HOLD':
            self.publish_zero_twist() 
            
            if now - self.hold_start >= 2.5:
                self.wp_idx += 1
                if self.wp_idx < len(self.waypoints):
                    self.get_logger().info(f"Moving to WP {self.wp_idx + 1}...")
                    self.state = 'TRACK'
                else:
                    self.get_logger().info("TASK 1B COMPLETE")
                    self.state = 'DONE'

        elif self.state == 'DONE':
            self.publish_zero_twist()

def main(args=None):
    rclpy.init(args=args)
    node = Task1BController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
